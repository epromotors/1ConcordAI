/* ══════════════════════════════════════════════
   ONE CONCORD AI — WEB ENGINE & LOGIC
   Preserving all client data structures & routing
   while activating GSAP, ScrollTrigger & SVG Line
   ══════════════════════════════════════════════ */

/* ── AGENT ICONS ───────────────────────────────────────── */
var AGENT_ICONS = {
  SD: '<i data-lucide="help-circle" style="width:17px;height:17px;"></i>',
  IM: '<i data-lucide="alert-circle" style="width:17px;height:17px;"></i>',
  RC: '<i data-lucide="search" style="width:17px;height:17px;"></i>',
  CM: '<i data-lucide="git-pull-request" style="width:17px;height:17px;"></i>',
  KI: '<i data-lucide="book-open" style="width:17px;height:17px;"></i>',
  AD: '<i data-lucide="server" style="width:17px;height:17px;"></i>',
  IA: '<i data-lucide="fingerprint" style="width:17px;height:17px;"></i>',
  SO: '<i data-lucide="shield" style="width:17px;height:17px;"></i>',
  CO: '<i data-lucide="cloud" style="width:17px;height:17px;"></i>',
  EI: '<i data-lucide="bar-chart-2" style="width:17px;height:17px;"></i>',
  CG: '<i data-lucide="file-check" style="width:17px;height:17px;"></i>',
  TC: '<i data-lucide="scan-eye" style="width:17px;height:17px;"></i>',
};

/* ── CLIENT DATA ─────────────────────────────────────────────── */
const AGENTS = [
  {code:'SD',name:'Service Desk Agent',domain:'IT & Operations',dom:'it',stat:'412',lbl:'Resolved / 24h',desc:'Autonomous first-contact IT resolution — VPN issues, password resets, software installs, and account management without creating a ticket.'},
  {code:'IM',name:'Incident Management Agent',domain:'IT & Operations',dom:'it',stat:'89',lbl:'Incidents / 24h',desc:'Alert triage, severity classification, blast radius assessment, stakeholder escalation, and post-incident review — fully automated.'},
  {code:'RC',name:'Root Cause Analysis Agent',domain:'IT & Operations',dom:'it',stat:'3 min',lbl:'Avg time to RCA',desc:'Correlates recent changes, alert patterns, and CMDB dependencies to identify root causes and prevent incident recurrence.'},
  {code:'CM',name:'Change Management Agent',domain:'IT & Operations',dom:'it',stat:'72%',lbl:'Auto-approved',desc:'Validates change risk, detects scheduling conflicts, routes approvals, monitors post-change health, and triggers rollback on failure.'},
  {code:'KI',name:'Knowledge Intelligence Agent',domain:'IT & Operations',dom:'it',stat:'4,812',lbl:'KB articles managed',desc:'Auto-generates knowledge articles from resolved incidents. Detects knowledge gaps. Keeps your knowledge base accurate and current.'},
  {code:'AD',name:'Asset Discovery & CMDB Agent',domain:'IT & Operations',dom:'it',stat:'18,420',lbl:'Assets tracked',desc:'Continuous discovery across cloud, endpoint, and network. Reconciles with Intune, ServiceNow, and AWS inventory automatically.'},
  {code:'IA',name:'Identity & Access Agent',domain:'Security & Cloud',dom:'sec',stat:'91%',lbl:'Autonomy rate',desc:'Full Joiner-Mover-Leaver lifecycle automation, access requests, entitlement reviews, and privileged access governance with SoD enforcement.'},
  {code:'SO',name:'Security Operations Agent',domain:'Security & Cloud',dom:'sec',stat:'94%',lbl:'Auto-contained',desc:'Tier-1 and Tier-2 SOC automation — alert triage, threat investigation, endpoint isolation, and autonomous incident response.'},
  {code:'CO',name:'Cloud Operations Agent',domain:'Security & Cloud',dom:'sec',stat:'$10K+',lbl:'Saved / month',desc:'Multi-cloud cost optimisation, security posture management, resource rightsizing, and one-click agent-validated remediation.'},
  {code:'EI',name:'Executive Intelligence Agent',domain:'Reporting & Compliance',dom:'leadership',stat:'8 sec',lbl:'Briefing generation',desc:'Natural language operational queries, auto-generated weekly briefings, real-time KPI tracking and cross-domain performance visibility.'},
  {code:'CG',name:'Compliance & Governance Agent',domain:'Reporting & Compliance',dom:'compliance',stat:'94%',lbl:'Avg compliance score',desc:'Continuous monitoring across ISO 27001, SOC 2, NESA, PDPL, and PCI DSS. Evidence collection, gap detection, audit readiness.'},
  {code:'TC',name:'Security Tool Coverage Agent',domain:'Reporting & Compliance',dom:'compliance',stat:'100%',lbl:'Asset visibility',desc:'Maps security tooling coverage across every asset — which endpoints have EDR, which servers are in SIEM scope, which cloud workloads lack monitoring. Identifies blind spots and reports coverage gaps automatically, continuously.'},
];

const TICKERS = [
  {code:'SD',bold:'Service Desk',rest:' reset VPN cert for 14 users — resolved in 38s'},
  {code:'IA',bold:'Identity Agent',rest:' provisioned 3 new joiners — Day-1 ready'},
  {code:'SO',bold:'Security Ops',rest:' isolated endpoint WS-FIN-0042 after EDR alert'},
  {code:'CO',bold:'Cloud Ops',rest:' stopped idle EC2 instance — saved $1,140/mo'},
  {code:'IM',bold:'Incident Mgmt',rest:' correlated 6 tickets to one root cause'},
  {code:'KI',bold:'Knowledge Agent',rest:' auto-generated KB article from resolved incident'},
  {code:'CG',bold:'Compliance',rest:' detected NESA control gap — remediation tasked'},
  {code:'EI',bold:'Exec Intelligence',rest:' generated Monday briefing — delivered in 8 sec'},
  {code:'TC',bold:'Tool Coverage',rest:' detected 3 unmonitored cloud workloads — gap report filed'},
  {code:'SD',bold:'Service Desk',rest:' resolved printer offline for 8 users in Finance — 22s'},
  {code:'IA',bold:'Identity Agent',rest:' revoked 34 entitlements for offboarded employee — 9 min'},
  {code:'RC',bold:'Root Cause',rest:' traced repeated CRM timeouts to misconfigured load balancer'},
  {code:'CM',bold:'Change Mgmt',rest:' auto-approved 12 low-risk patches — deploy window locked in'},
  {code:'SO',bold:'Security Ops',rest:' blocked phishing campaign — 47 malicious emails retracted'},
  {code:'CO',bold:'Cloud Ops',rest:' rightsized 6 oversized RDS instances — saving $3,200/mo'},
  {code:'AD',bold:'Asset Discovery',rest:' found 3 unregistered servers — CMDB reconciled automatically'},
  {code:'EI',bold:'Exec Intelligence',rest:' answered "Why did ticket volume spike Tuesday?" in 4 sec'},
  {code:'CG',bold:'Compliance',rest:' collected SOC 2 evidence package — audit-ready in 4 hours'},
  {code:'TC',bold:'Tool Coverage',rest:' flagged 5 endpoints missing EDR — gap report sent to CISO'},
  {code:'IM',bold:'Incident Mgmt',rest:' paged on-call and triaged alert in 90s — zero human touch'},
  {code:'KI',bold:'Knowledge Agent',rest:' detected stale KB article — updated from 3 recent incidents'},
  {code:'IA',bold:'Identity Agent',rest:' flagged SoD conflict on finance role — access request blocked'},
  {code:'SD',bold:'Service Desk',rest:' provisioned Adobe CC licence from pool — ticket closed in 41s'},
  {code:'CO',bold:'Cloud Ops',rest:' detected public S3 bucket — permissions reverted in 4 min'},
];

const SOLUTIONS = {
  it:{
    title:'IT Operations',
    tagline:'6 agents. Zero tickets. Every issue resolved before it becomes one.',
    body:'One Concord AI eliminates the IT service desk backlog entirely. Six agents covering Service Desk, Incident Management, Root Cause Analysis, Change Management, Knowledge Intelligence, and Asset Discovery work in concert — detecting, diagnosing, and resolving issues before employees ever need to raise a ticket.',
    agents:['SD','IM','RC','CM','KI','AD'],
    metrics:[['78%','Autonomous resolution rate'],['38s','Avg time to resolve'],['412','Requests / 24h']],
    caps:['Autonomous password resets, VPN fixes, and software installs — zero tickets','P1 incident triage with automated stakeholder communication','Root cause correlation across recent changes and CMDB','Auto-generated knowledge articles from every resolved incident','Continuous asset discovery — CMDB always current, no manual reconciliation','Scheduled maintenance window management with auto-approval and rollback triggers','SLA breach prediction — escalation initiated before the breach clock runs out','Multi-site hardware refresh tracking with automated decommission workflows'],
    usecases:[
      {title:'After-hours IT outage',body:'Incident Management Agent classifies the severity, pages on-call engineers, and posts status updates to Teams — all in under 90 seconds, without a human touching Slack.'},
      {title:'New software licence request',body:'Employee requests Adobe Creative Cloud. Service Desk Agent checks licence pool, verifies approval policy, provisions the licence, and closes the ticket in 41 seconds.'},
      {title:'CMDB drift detected',body:'Asset Discovery Agent finds 3 unregistered servers during a routine sweep. Tickets are raised, owners are identified from AD, and records are reconciled before the next audit window.'},
      {title:'Recurring incident pattern',body:'RCA Agent detects that 12 incidents over 30 days share the same upstream dependency. A change request is auto-drafted and routed for approval before the next failure.'},
    ],
  },
  security:{
    title:'Security & Cloud',
    tagline:'3 agents. Identity, security, and cloud — unified.',
    body:'The Security & Cloud domain brings together Identity & Access, Security Operations, and Cloud Operations agents into a single coordinated layer. Together they protect your enterprise perimeter, enforce access policies, and govern cloud spend and posture — all autonomously.',
    agents:['IA','SO','CO'],
    metrics:[['94%','Alerts auto-contained'],['91%','Identity autonomy rate'],['$10K+','Saved / month']],
    caps:['Autonomous endpoint isolation on EDR detection','Phishing email retraction across all inboxes on confirmation','New employee fully provisioned — Day-1 ready','Privileged access with dual-approval and full session recording','Multi-cloud cost optimisation, rightsizing, and idle resource termination','Public storage exposure detected and locked within minutes','Shadow IT detection — unsanctioned SaaS apps flagged from DNS and network logs','Quarterly SoD conflict review across all roles, auto-remediated where policy allows','Reserved Instance and Savings Plan optimisation recommendations','Tag policy enforcement — untagged resources auto-tagged or flagged for owner review'],
    usecases:[
      {title:'Ransomware early warning',body:'EDR alert fires on WS-FIN-0042. Security Ops Agent isolates the endpoint, snapshots the disk, notifies the CISO, and opens a P1 incident — all in under 2 minutes.'},
      {title:'Terminated employee access',body:'HR triggers offboarding. Identity Agent revokes all 34 SaaS and on-prem entitlements, disables the AD account, and archives the mailbox in 9 minutes with a full audit trail.'},
      {title:'Cloud security misconfiguration',body:'A storage bucket is inadvertently made public. Cloud Ops Agent detects the exposure within 4 minutes, reverts permissions, and alerts the security team with a full change log.'},
      {title:'Runaway cloud spend',body:'Cloud Ops Agent detects a dev environment left running over the weekend. It stops the instances, notifies the owner, and files an optimisation record — saving thousands before Monday morning.'},
    ],
  },
  leadership:{
    title:'Reporting & Compliance',
    tagline:'3 agents. Intelligence, governance, and full security visibility.',
    body:'The Reporting & Compliance domain brings together the Executive Intelligence Agent, Compliance & Governance Agent, and Security Tool Coverage Agent. Together they give leadership a complete picture — operational briefings, continuous compliance monitoring, and a live view of where security tooling coverage stands across every asset in the organisation.',
    agents:['EI','CG','TC'],
    metrics:[['8 sec','Briefing generation time'],['94%','Avg compliance score'],['100%','Asset visibility target']],
    caps:['Weekly operational briefing auto-generated every Monday at 08:00','Natural language queries: "Why did ticket volume increase this week?"','Real-time ROI tracking: cost saved, MTTR reduction, deflection rate','Cross-domain anomaly surfacing: patterns a human analyst would miss','Board-ready metrics exported on demand','Real-time control monitoring — gaps detected within minutes of a change','Automatic evidence collection for SOC 2 auditor review','NESA Article 30 control mapping and quarterly submission support','Audit readiness score updated daily across all active frameworks','Continuous mapping of EDR, SIEM, and monitoring coverage across all assets','Blind spot detection — unmonitored endpoints, servers, and cloud workloads surfaced automatically','Weekly coverage gap report delivered to CISO with asset-level detail and remediation priority'],
    usecases:[
      {title:'Monday morning briefing',body:'Executives open their laptop at 08:00 to find a 3-paragraph operational summary covering all active domains, risk flags, and cost-saving wins — generated overnight without human input.'},
      {title:'Board report preparation',body:'"Generate a board-ready operational summary for Q2." Executive Agent produces a structured report with metrics, trends, incidents, and savings in 8 seconds — formatted for export.'},
      {title:'Coverage gap discovered',body:'Security Tool Coverage Agent detects 3 cloud workloads spun up by engineering with no EDR or SIEM coverage. A gap report is filed, owners notified, and the finding escalated to executive dashboard — before any threat can exploit the blind spot.'},
      {title:'Surprise regulatory audit',body:'Regulator requests evidence of access controls for the past 6 months. Compliance Agent assembles the full evidence package in 4 hours — what would have taken two weeks manually.'},
    ],
  },
};

/* ── SPA ROUTER ───────────────────────────────────────────── */
function go(id) {
  document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
  var pg = document.getElementById('pg-' + id);
  if (pg) pg.classList.add('active');

  document.querySelectorAll('.nav-a').forEach(function(a) { a.classList.remove('act'); });
  document.querySelectorAll('.nav-a[data-pg="' + id + '"]').forEach(function(a) { a.classList.add('act'); });

  window.location.hash = '#' + id;
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Re-render subpage specific assets and refresh ScrollTrigger
  if (id === 'agents') {
    buildAgentGrid();
    buildAgentExtras();
  }
  if (id === 'solutions') {
    buildSolutions('it');
  }

  // Allow layout calculations to complete before refreshing
  setTimeout(() => {
    ScrollTrigger.refresh();
    if (typeof updatePathDimensions === 'function') {
      updatePathDimensions();
    }
  }, 100);
}

function toggleMob() {
  document.getElementById('mobMenu').classList.toggle('open');
}

function toggleMob() {
  var menu = document.getElementById('mobMenu');
  if (menu) menu.classList.toggle('open');
}

/* ── BUILD: NAV ───────────────────────────────────────── */
function buildNav() {
  var navLinks = document.getElementById('navLinks');
  var navEnd = document.getElementById('navEnd');
  if (!navLinks || !navEnd) return;

  navLinks.innerHTML = '';
  navEnd.innerHTML = '';

  ['Home|home','Platform|platform','Agents|agents','Solutions|solutions','Pricing|pricing','About|about'].forEach(function(pair){
    var parts = pair.split('|');
    var label = parts[0], page = parts[1];
    var a = document.createElement('button');
    a.className = 'nav-a'; a.setAttribute('data-pg', page); a.textContent = label;
    a.onclick = function() { go(page); };
    navLinks.appendChild(a);
  });

  var demoBtn = document.createElement('button');
  demoBtn.className = 'btn btn-ghost btn-sm'; demoBtn.textContent = 'Book a Demo';
  demoBtn.onclick = function() { go('contact'); };
  
  var startBtn = document.createElement('button');
  startBtn.className = 'btn btn-primary btn-sm'; startBtn.textContent = 'Get Started →';
  startBtn.onclick = function() { go('contact'); };

  navEnd.appendChild(demoBtn);
  navEnd.appendChild(startBtn);

  var mobLinks = document.getElementById('mobLinks');
  if (mobLinks) {
    mobLinks.innerHTML = '';
    ['Home|home','Platform|platform','Agents|agents','Solutions|solutions','Pricing|pricing','About|about','Contact|contact'].forEach(function(pair){
      var parts = pair.split('|');
      var btn = document.createElement('button');
      btn.className = 'mob-a'; btn.textContent = parts[0];
      btn.onclick = function() { go(parts[1]); toggleMob(); };
      mobLinks.appendChild(btn);
    });
  }
}

/* ── BUILD: TICKER ────────────────────────────────────── */
function buildTicker() {
  var track = document.getElementById('tickerTrack');
  if (!track) return;
  track.innerHTML = '';
  var items = TICKERS.concat(TICKERS); // duplicate for seamless loop
  items.forEach(function(t) {
    var d = document.createElement('div');
    d.className = 'tick';
    var ico = document.createElement('div');
    ico.className = 'tick-ico'; ico.textContent = t.code;
    var txt = document.createElement('span');
    txt.innerHTML = '<b>' + t.bold + '</b>' + t.rest;
    d.appendChild(ico); d.appendChild(txt);
    track.appendChild(d);
  });
}

/* ── BUILD: HOME ──────────────────────────────────────── */
function buildHome() {
  // How it works steps
  var stepsEl = document.getElementById('howSteps');
  if (stepsEl) {
    stepsEl.innerHTML = '';
    var steps = [
      ['01','Understand',
       'Intent engine identifies what is being requested, who is asking, and which systems, data, and business context are involved.',
       '<i data-lucide="eye" style="width:22px;height:22px;"></i>',
       'var(--accent)'],
      ['02','Reason',
       'Knowledge engine retrieves enterprise context, relationships, history, and dependencies, enabling the agent to reason before acting.',
       '<i data-lucide="brain" style="width:22px;height:22px;"></i>',
       'var(--accent)'],
      ['03','Decide',
       'Policy engine evaluates risk, permissions, and governance rules to auto-execute, request approval, notify, or reject.',
       '<i data-lucide="shield-check" style="width:22px;height:22px;"></i>',
       'var(--accent)'],
      ['04','Execute',
       'Connector service performs authenticated API calls and orchestrates workflows — atomic, retryable, observable, and fully audited.',
       '<i data-lucide="zap" style="width:22px;height:22px;"></i>',
       'var(--accent)'],
      ['05','Learn',
       'Outcomes are written to the knowledge graph and vector store, continuously improving reasoning, decisions, and future execution.',
       '<i data-lucide="refresh-cw" style="width:22px;height:22px;"></i>',
       'var(--gold)'],
    ];
    stepsEl.className = 'timeline-container';
    
    // Create progress lines
    var bgLine = document.createElement('div');
    bgLine.className = 'timeline-line';
    var progressLine = document.createElement('div');
    progressLine.className = 'timeline-line-progress';
    progressLine.id = 'timelineProgress';
    stepsEl.appendChild(bgLine);
    stepsEl.appendChild(progressLine);

    // Illustration Graphics HTML Generator
    function getGraphicHTML(num) {
      if (num === '01') {
        return '<div class="illustration-container">'
          + '<div class="console-box">'
          + '  <div class="console-head">'
          + '    <span class="dot red"></span><span class="dot yellow"></span><span class="dot green"></span>'
          + '    <span class="console-title">Intent Analysis</span>'
          + '  </div>'
          + '  <div class="console-body">'
          + '    <div class="console-prompt">&gt; Add user @john.doe to #alerts</div>'
          + '    <div class="console-response">'
          + '      <div class="field"><span class="lbl">INTENT:</span> <span class="val cyan">SLACK_INVITE</span></div>'
          + '      <div class="field"><span class="lbl">USER:</span> <span class="val">john.doe</span></div>'
          + '      <div class="field"><span class="lbl">CONFIDENCE:</span> <span class="val gold">99.8%</span></div>'
          + '    </div>'
          + '  </div>'
          + '</div>'
          + '</div>';
      } else if (num === '02') {
        return '<div class="illustration-container">'
          + '<div class="graph-wrapper">'
          + '  <svg class="graph-svg" width="100%" height="100%">'
          + '    <line x1="50%" y1="50%" x2="20%" y2="22%" stroke="rgba(20,184,166,0.3)" stroke-width="1.5" stroke-dasharray="4" style="animation: flowLine 20s linear infinite;"></line>'
          + '    <line x1="50%" y1="50%" x2="80%" y2="22%" stroke="rgba(20,184,166,0.3)" stroke-width="1.5" stroke-dasharray="4" style="animation: flowLine 20s linear infinite;"></line>'
          + '    <line x1="50%" y1="50%" x2="20%" y2="78%" stroke="rgba(20,184,166,0.3)" stroke-width="1.5" stroke-dasharray="4" style="animation: flowLine 20s linear infinite;"></line>'
          + '    <line x1="50%" y1="50%" x2="80%" y2="78%" stroke="rgba(20,184,166,0.3)" stroke-width="1.5" stroke-dasharray="4" style="animation: flowLine 20s linear infinite;"></line>'
          + '  </svg>'
          + '  <div class="graph-node center pulse-glow">Context</div>'
          + '  <div class="graph-node pos-tl float-node-1">Slack Profile</div>'
          + '  <div class="graph-node pos-tr float-node-2">Okta ID</div>'
          + '  <div class="graph-node pos-bl float-node-3">Active Dir</div>'
          + '  <div class="graph-node pos-br float-node-4">Device Risk</div>'
          + '</div>'
          + '</div>';
      } else if (num === '03') {
        return '<div class="illustration-container">'
          + '<div class="policy-wrapper">'
          + '  <div class="policy-shield">'
          + '    <i data-lucide="shield" class="shield-icon" style="width:36px;height:36px;"></i>'
          + '  </div>'
          + '  <div class="policy-checklist">'
          + '    <div class="check-item"><i data-lucide="check-circle" class="check-icon green" style="width:16px;height:16px;margin-right:8px;color:var(--accent);"></i><span>MFA Verified</span></div>'
          + '    <div class="check-item"><i data-lucide="check-circle" class="check-icon green" style="width:16px;height:16px;margin-right:8px;color:var(--accent);"></i><span>RBAC Access OK</span></div>'
          + '    <div class="check-item"><i data-lucide="check-circle" class="check-icon green" style="width:16px;height:16px;margin-right:8px;color:var(--accent);"></i><span>Risk Score: 0.04</span></div>'
          + '  </div>'
          + '</div>'
          + '</div>';
      } else if (num === '04') {
        return '<div class="illustration-container">'
          + '<div class="execution-pipeline">'
          + '  <div class="pipeline-node done">'
          + '    <div class="node-label">Verify</div>'
          + '    <div class="node-status">✓</div>'
          + '  </div>'
          + '  <div class="pipeline-arrow active"></div>'
          + '  <div class="pipeline-node running">'
          + '    <div class="node-label">API Trigger</div>'
          + '    <div class="node-status loader-spin"></div>'
          + '  </div>'
          + '  <div class="pipeline-arrow"></div>'
          + '  <div class="pipeline-node pending">'
          + '    <div class="node-label">Audit Log</div>'
          + '    <div class="node-status">···</div>'
          + '  </div>'
          + '</div>'
          + '</div>';
      } else if (num === '05') {
        return '<div class="illustration-container">'
          + '<div class="learning-panel">'
          + '  <div class="learning-header">'
          + '    <span class="pulse-dot-gold"></span>'
          + '    <span class="panel-title">Vector Memory & Graph Sync</span>'
          + '  </div>'
          + '  <div class="learning-body">'
          + '    <div class="db-stack">'
          + '      <div class="db-layer"><i data-lucide="database" class="db-layer-icon"></i> <span>Vector Store</span></div>'
          + '      <div class="db-layer active"><i data-lucide="git-branch" class="db-layer-icon"></i> <span>Knowledge Graph</span></div>'
          + '    </div>'
          + '    <div class="feedback-connector">'
          + '      <svg class="arrow-svg" viewBox="0 0 60 40" fill="none">'
          + '        <path d="M 50,30 C 50,10 10,10 10,30" stroke="var(--gold)" stroke-width="2" stroke-dasharray="4" class="arrow-path" style="animation: flowLine 15s linear infinite;"></path>'
          + '        <polygon points="10,30 5,22 15,22" fill="var(--gold)"></polygon>'
          + '      </svg>'
          + '      <span class="connector-label">Feedback</span>'
          + '    </div>'
          + '    <div class="updated-node-box">'
          + '      <div class="node-badge-gold">Graph Synced</div>'
          + '      <div class="node-meta">Outcomes Logged</div>'
          + '    </div>'
          + '  </div>'
          + '</div>'
          + '</div>';
      }
      return '';
    }

    steps.forEach(function(s, index) {
      var num = s[0], title = s[1], desc = s[2], icon = s[3], dotColor = s[4];
      var isGold = dotColor === 'var(--gold)';
      var item = document.createElement('div');
      item.className = 'timeline-item ' + (index % 2 === 0 ? 'timeline-left' : 'timeline-right');
      
      var badge = document.createElement('div');
      badge.className = 'timeline-badge';
      if (isGold) {
        badge.style.borderColor = 'var(--gold)';
        badge.style.color = 'var(--gold)';
      }
      badge.innerHTML = icon;

      var content = document.createElement('div');
      content.className = 'timeline-content';
      content.innerHTML = '<div class="timeline-header-row">'
        + '<div class="timeline-step' + (isGold ? ' gold' : '') + '">Step ' + num + '</div>'
        + '<div class="timeline-card-icon">' + icon + '</div>'
        + '</div>'
        + '<div class="timeline-title">' + title + '</div>'
        + '<div class="timeline-desc">' + desc + '</div>';

      var graphic = document.createElement('div');
      graphic.className = 'timeline-graphic';
      graphic.innerHTML = getGraphicHTML(num);

      // Alternating Grid Column Layout for Desktop
      if (index % 2 === 0) {
        item.appendChild(content);
        item.appendChild(graphic);
      } else {
        item.appendChild(graphic);
        item.appendChild(content);
      }

      item.appendChild(badge);
      stepsEl.appendChild(item);
    });
  }

  // Testimonials Slider
  var testimonialsTrack = document.getElementById('testimonialsTrack');
  if (testimonialsTrack) {
    testimonialsTrack.innerHTML = '';
    var testimonials = [
      {
        quote: 'We went from 400 weekly IT tickets to 82. The Service Desk Agent handles the rest — no escalations, no delays. Our team now focuses on architecture and innovation.',
        name: 'Aisha Verma',
        initials: 'AV',
        role: 'Head of IT Operations',
        org: 'NovaBank',
        avatarBg: '#00d2ff'
      },
      {
        quote: 'Our SOC team was drowning in L1 alerts. The Security Operations Agent now handles 94% of them without human intervention. Our analysts finally have time to hunt threats.',
        name: 'Daniel Brooks',
        initials: 'DB',
        role: 'CISO',
        org: 'CloudAxis',
        avatarBg: '#a855f7'
      },
      {
        quote: 'We had no idea 14 servers were outside our SIEM scope until the Security Tool Coverage Agent flagged them in its first weekly report. That was a game changer.',
        name: 'Rohan Mehta',
        initials: 'RM',
        role: 'Head of Security Operations',
        org: 'VertexOne',
        avatarBg: '#14b8a6'
      },
      {
        quote: 'The Cloud Operations Agent identified over $600K in annual wasted cloud spend within its first week. The ROI conversation with our board lasted about four minutes.',
        name: 'Sarah Jenkins',
        initials: 'SJ',
        role: 'VP of Cloud Infrastructure',
        org: 'GlobalTech',
        avatarBg: '#f59e0b'
      },
      {
        quote: 'We passed our ISO 27001 recertification with zero findings for the first time. The Compliance Agent had been collecting evidence and flagging gaps continuously.',
        name: 'Marcus Vance',
        initials: 'MV',
        role: 'Head of GRC',
        org: 'Sovereign Insure',
        avatarBg: '#ec4899'
      },
      {
        quote: 'I receive a natural-language operational briefing every Monday at 08:00. It covers IT, security, cloud spend, and compliance posture — synthesised in eight seconds.',
        name: 'Elena Rostova',
        initials: 'ER',
        role: 'Chief Technology Officer',
        org: 'Fintech Enterprise',
        avatarBg: '#3b82f6'
      }
    ];
    // Duplicate testimonials for infinite horizontal scrolling loop
    var doubleTestimonials = testimonials.concat(testimonials);
    doubleTestimonials.forEach(function(t) {
      var card = document.createElement('div');
      card.className = 'testimonial-card-slide';
      card.innerHTML = 
          '<div class="testimonial-stars">★★★★★</div>'
        + '<div class="testimonial-quote-mark">“</div>'
        + '<p class="testimonial-text">' + t.quote + '</p>'
        + '<div class="testimonial-footer">'
        + '  <div class="testimonial-avatar" style="background-color: ' + t.avatarBg + '; color: #0b0f19;">' + t.initials + '</div>'
        + '  <div class="testimonial-meta">'
        + '    <div class="testimonial-name">' + t.name + '</div>'
        + '    <div class="testimonial-role">' + t.role + '</div>'
        + '    <div class="testimonial-org-badge">' + t.org + '</div>'
        + '  </div>'
        + '</div>';
      testimonialsTrack.appendChild(card);
    });
  }

}

/* ── BUILD: PLATFORM ──────────────────────────────────── */
function buildPlatform() {
  var servicesEl = document.getElementById('platformServices');
  if (servicesEl) {
    servicesEl.innerHTML = '';
    var services = [
      ['API Gateway',
       'Every channel — Teams, web portal, email, REST API — enters here. Authentication, rate limiting, tenant routing, and WebSocket server for real-time streaming.',
       '<i data-lucide="network" style="width:21px;height:21px;"></i>'],
      ['Orchestration Service',
       'Intent extraction, agent routing, multi-agent coordination, and real-time status streaming. The brain that decides who handles what.',
       '<i data-lucide="git-branch" style="width:21px;height:21px;"></i>'],
      ['Agent Runtime',
       'LangGraph reasoning + Temporal durable execution. Each agent runs a 5-step lifecycle (Understand → Reason → Decide → Execute → Learn) with full state management and retries.',
       '<i data-lucide="play" style="width:21px;height:21px;"></i>'],
      ['Connector Service',
       '70+ integrations. Every API call wrapped with authentication, retry logic, circuit breaking, rate limiting, and an immutable audit hook.',
       '<i data-lucide="link" style="width:21px;height:21px;"></i>'],
      ['Knowledge & Policy Service',
       'Neo4j organisational knowledge graph + Weaviate vector store. Policy engine evaluates risk before every action. Nothing executes without a verdict.',
       '<i data-lucide="shield" style="width:21px;height:21px;"></i>'],
      ['Audit Service',
       'Append-only, hash-chained, immutable event log. Every decision, action, and escalation — retained for 1 year (Enterprise) or 90 days (Starter). SOC 2 and NESA compliant.',
       '<i data-lucide="history" style="width:21px;height:21px;"></i>'],
    ];
    servicesEl.className = 'g3';
    services.forEach(function(s) {
      var card = document.createElement('div');
      card.className = 'card fade-up';
      card.setAttribute('data-line-card', '');
      card.innerHTML = '<div class="ficon">' + s[2] + '</div>'
        + '<h4 class="mb-sm">' + s[0] + '</h4>'
        + '<p style="font-size:13.5px">' + s[1] + '</p>';
      servicesEl.appendChild(card);
    });
  }

  var stepsEl = document.getElementById('execFlow');
  if (stepsEl) {
    stepsEl.innerHTML = '';
    var execSteps = [
      ['Request received','Via Teams, web portal, email, or REST API'],
      ['Authentication','JWT/SSO validated, tenant context extracted'],
      ['Intent classification','LLM extracts intent, entities, and urgency level'],
      ['Knowledge lookup','Neo4j graph queried for organisational context'],
      ['Risk assessment','Policy engine scores the action (0 to 1.0)'],
      ['Route decision','AUTO / NOTIFY / APPROVE / REJECT'],
      ['Connector execution','Action taken via authenticated API call'],
      ['Audit record','Immutable log written with full trace and diff'],
    ];
    execSteps.forEach(function(s, i) {
      var row = document.createElement('div');
      row.style.cssText = 'display:flex;gap:12px;align-items:flex-start; margin-bottom:12px;';
      row.className = 'fade-up';
      row.innerHTML = '<div class="step-dot">' + (i < 9 ? '0' : '') + (i + 1) + '</div>'
        + '<div><div style="font-size:13.5px;font-weight:700;color:var(--text-1)">' + s[0] + '</div><div style="font-size:12.5px;color:var(--text-3);margin-top:2px">' + s[1] + '</div></div>';
      stepsEl.appendChild(row);
    });
  }

  var riskRows = document.getElementById('riskRows');
  if (riskRows) {
    riskRows.innerHTML = '';
    var factors = [
      ['Action type','Read 0.1 → Write 0.4 → Delete 0.7 → Bulk 0.95'],
      ['System criticality','P1 systems always require approval'],
      ['Requester identity','Known employee vs contractor vs unverified'],
      ['Time of day','After-hours on critical systems adds 0.2'],
      ['Recent changes','Same system change in last 2h adds 0.3'],
      ['SoD conflict','Self-approve = auto-reject, always'],
    ];
    factors.forEach(function(f) {
      var row = document.createElement('div');
      row.className = 'fade-up';
      row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:9px 12px;background:rgba(255,255,255,0.04);border-radius:7px;border:1px solid rgba(255,255,255,.08);margin-bottom:8px;';
      row.innerHTML = '<span style="font-size:12.5px;color:var(--text-2)">' + f[0] + '</span><span style="font-size:11.5px;color:var(--accent);font-family:var(--mono)">' + f[1] + '</span>';
      riskRows.appendChild(row);
    });
  }

  var riskPills = document.getElementById('riskPills');
  if (riskPills) {
    riskPills.innerHTML = '';
    var routes = [['< 0.3','AUTO EXECUTE'],['0.3 – 0.6','NOTIFY + EXECUTE'],['0.6 – 0.8','REQUIRE APPROVAL'],['> 0.8','REJECT']];
    riskPills.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:6px';
    routes.forEach(function(r) {
      var pill = document.createElement('div');
      pill.style.cssText = 'padding:8px 10px;background:rgba(0,0,0,.2);border-radius:7px;font-size:11.5px';
      pill.className = 'fade-up';
      pill.innerHTML = '<div style="color:var(--gold);font-family:var(--mono);font-weight:600;margin-bottom:3px">' + r[0] + '</div><div style="color:var(--text-1);font-weight:700;font-size:10px">' + r[1] + '</div>';
      riskPills.appendChild(pill);
    });
  }

  var isoEl = document.getElementById('isoLayers');
  if (isoEl) {
    isoEl.innerHTML = '';
    var layers = [
      ['Database',
       'PostgreSQL Row-Level Security — tenant_id enforced at DB level, not application level. Cross-tenant queries are impossible.',
       '<i data-lucide="database" style="width:18px;height:18px;"></i>'],
      ['Knowledge Graph',
       'Neo4j tenant_id on all nodes. Query interceptor prepends tenant filter to every Cypher statement automatically.',
       '<i data-lucide="network" style="width:18px;height:18px;"></i>'],
      ['Message Bus',
       "Kafka topics prefixed with tenant ID. Consumer groups isolated. One tenant's events cannot reach another's agents.",
       '<i data-lucide="list" style="width:18px;height:18px;"></i>'],
      ['File Storage',
       'Separate S3 prefix namespace per tenant. IAM policies enforce prefix boundaries at the AWS infrastructure level.',
       '<i data-lucide="folder-open" style="width:18px;height:18px;"></i>'],
      ['Agent Execution',
       'Temporal workflow namespace per tenant. Cross-tenant connector access is architecturally impossible.',
       '<i data-lucide="shield-check" style="width:18px;height:18px;"></i>'],
      ['Vector Search',
       'Weaviate separate class per tenant. API key scoped to tenant class. Semantic search cannot return cross-tenant results.',
       '<i data-lucide="search" style="width:18px;height:18px;"></i>'],
    ];
    layers.forEach(function(l) {
      var card = document.createElement('div');
      card.className = 'card card-teal fade-up';
      card.innerHTML = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">'
        + '<div style="width:34px;height:34px;border-radius:9px;background:rgba(20,184,166,.15);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--accent);flex-shrink:0">' + l[2] + '</div>'
        + '<h4 style="font-size:13.5px;margin:0">' + l[0] + '</h4>'
        + '</div>'
        + '<p style="font-size:13px">' + l[1] + '</p>';
      isoEl.appendChild(card);
    });
  }
}

/* ── BUILD: AGENTS ────────────────────────────────────── */
function buildAgentGrid() {
  var container = document.getElementById('agentGrid');
  if (!container || container.dataset.built) return;
  container.dataset.built = '1';

  var domainConfig = {
    'IT & Operations': {color:'rgba(20,184,166,.12)',text:'var(--accent)',icon:'<i data-lucide="monitor" style="width:16px;height:16px;"></i>'},
    'Security & Cloud': {color:'rgba(20,184,166,.08)',text:'var(--accent)',icon:'<i data-lucide="shield" style="width:16px;height:16px;"></i>'},
    'Reporting & Compliance': {color:'rgba(245,158,11,.15)',text:'var(--gold)',icon:'<i data-lucide="file-check" style="width:16px;height:16px;"></i>'},
  };

  var domains = {};
  var order = [];
  AGENTS.forEach(function(a) {
    if (!domains[a.domain]) { domains[a.domain] = []; order.push(a.domain); }
    domains[a.domain].push(a);
  });

  order.forEach(function(domain) {
    var agents = domains[domain];
    var cfg = domainConfig[domain] || {color:'rgba(255,255,255,.05)',text:'var(--text-3)',icon:'AG'};
    var section = document.createElement('div');
    section.style.cssText = 'margin-bottom:40px';

    var header = document.createElement('div');
    header.style.cssText = 'display:flex;align-items:center;gap:12px;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.07)';
    header.innerHTML = '<div style="width:36px;height:36px;border-radius:9px;background:' + cfg.color + ';border:1px solid ' + cfg.text + ';display:flex;align-items:center;justify-content:center;color:' + cfg.text + ';flex-shrink:0">' + cfg.icon + '</div>'
      + '<div style="flex:1"><h3 style="font-size:17px;font-weight:800;color:var(--text-1);margin:0">' + domain + '</h3><div style="font-size:12px;color:var(--text-3);margin-top:2px">' + agents.length + ' agent' + (agents.length > 1 ? 's' : '') + '</div></div>';
    section.appendChild(header);

    var grid = document.createElement('div');
    grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:10px';

    agents.forEach(function(a) {
      var card = document.createElement('div');
      card.style.cssText = 'background:rgba(26,58,92,0.2);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:16px 18px;display:flex;gap:14px;align-items:flex-start;transition:all .18s; cursor:pointer;';
      card.onmouseenter = function() { this.style.borderColor = 'var(--accent)'; this.style.transform = 'translateY(-2px)'; };
      card.onmouseleave = function() { this.style.borderColor = 'rgba(255,255,255,.07)'; this.style.transform = 'none'; };
      card.innerHTML =
        '<div style="width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,rgba(26,58,92,0.4),rgba(15,31,61,0.5));border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--accent);flex-shrink:0">' + (AGENT_ICONS[a.code] || a.code) + '</div>'
        + '<div style="flex:1;min-width:0">'
        + '<div style="display:flex;align-items:baseline;justify-content:space-between;gap:8px;margin-bottom:5px">'
        + '<div style="font-size:13.5px;font-weight:700;color:var(--text-1)">' + a.name + '</div>'
        + '<div style="text-align:right;flex-shrink:0"><span style="font-family:var(--mono);font-size:13px;font-weight:600;color:var(--accent)">' + a.stat + '</span> <span style="font-size:10.5px;color:var(--text-3)">' + a.lbl + '</span></div>'
        + '</div>'
        + '<p style="font-size:12.5px;color:var(--text-3);line-height:1.5;margin:0">' + a.desc + '</p>'
        + '</div>';
      grid.appendChild(card);
    });

    section.appendChild(grid);
    container.appendChild(section);
  });
  lucide.createIcons();
}

function buildAgentExtras() {
  var impactGrid = document.getElementById('agentImpactGrid');
  if (impactGrid && !impactGrid.dataset.built) {
    impactGrid.dataset.built = '1';
    impactGrid.innerHTML = '';
    var impacts = [
      {num:'$650K+',lbl:'Annual savings per customer',sub:'Operational cost reduction'},
      {num:'78%',lbl:'Autonomous resolution rate',sub:'Across all IT agent actions'},
      {num:'94%',lbl:'Compliance score maintained',sub:'Continuous control monitoring'},
      {num:'94%',lbl:'Security alerts auto-contained',sub:'Without human SOC intervention'},
      {num:'100%',lbl:'Asset visibility target',sub:'No endpoint, server, or workload unmonitored'},
      {num:'<48h',lbl:'Compliance gap to remediation',sub:'Detect → assign → close'},
      {num:'70+',lbl:'Connectors out of the box',sub:'ServiceNow, Jira, Workday, AWS & more'},
      {num:'5 days',lbl:'Contract to first live action',sub:'Fastest enterprise onboarding in the market'},
    ];
    impacts.forEach(function(imp) {
      var card = document.createElement('div');
      card.className = 'card fade-up';
      card.style.cssText = 'text-align:center;padding:22px 16px';
      card.innerHTML = '<div style="font-family:var(--mono);font-size:26px;font-weight:700;color:var(--accent);line-height:1;margin-bottom:8px">' + imp.num + '</div>'
        + '<div style="font-size:13px;font-weight:700;color:var(--text-1);margin-bottom:4px">' + imp.lbl + '</div>'
        + '<div style="font-size:11.5px;color:var(--text-3)">' + imp.sub + '</div>';
      impactGrid.appendChild(card);
    });
  }

  var band = document.getElementById('integrationBand');
  if (band && !band.dataset.built) {
    band.dataset.built = '1';
    band.innerHTML = '';
    var integrations = ['ServiceNow','Jira','Workday','Microsoft Entra ID','Microsoft 365','AWS','Azure','GCP','Slack','Teams','Okta','CrowdStrike','SentinelOne','Splunk','Tenable','Qualys','Datadog','PagerDuty','GitHub','GitLab','SAP','Oracle ERP','NetSuite','Coupa','Ariba','Zoom','DocuSign','Freshservice','Zendesk','Intune'];
    integrations.forEach(function(name) {
      var pill = document.createElement('div');
      pill.className = 'cbadge fade-up';
      pill.style.cssText = 'font-size:12px;padding:8px 14px';
      pill.textContent = name;
      band.appendChild(pill);
    });
  }
}

/* ── BUILD: SOLUTIONS ─────────────────────────────────── */
function buildSolutions(id, btn) {
  if (btn) {
    document.querySelectorAll('.sol-tab').forEach(function(b) { b.classList.remove('act'); });
    btn.classList.add('act');
  } else {
    var first = document.querySelector('.sol-tab');
    if (first) first.classList.add('act');
  }
  var s = SOLUTIONS[id];
  if (!s) return;
  var container = document.getElementById('solContent');
  if (!container) return;
  container.innerHTML = '';

  var agentData = AGENTS.filter(function(a) { return s.agents.indexOf(a.code) !== -1; });

  // ── TOP BAND: tagline + metrics ──
  var topBand = document.createElement('div');
  topBand.className = 'sol-top-band fade-up';
  var topLeft = document.createElement('div');
  topLeft.innerHTML = '<div class="eyebrow">' + s.title + '</div>'
    + '<div class="sol-tagline">' + s.tagline + '</div>'
    + '<div class="sol-body">' + s.body + '</div>';
  var mets = document.createElement('div');
  mets.className = 'sol-mets';
  s.metrics.forEach(function(m) {
    var met = document.createElement('div');
    met.className = 'sol-met';
    met.innerHTML = '<div class="sol-met-v">' + m[0] + '</div><div class="sol-met-l">' + m[1] + '</div>';
    mets.appendChild(met);
  });
  topBand.appendChild(topLeft);
  topBand.appendChild(mets);
  container.appendChild(topBand);

  // ── MAIN GRID: agents | capabilities ──
  var mgrid = document.createElement('div');
  mgrid.className = 'sol-mgrid';

  // COL 1: agent cards
  var leftCol = document.createElement('div');
  var agHd = document.createElement('div');
  agHd.className = 'sol-col-hd';
  agHd.textContent = 'Agents included';
  leftCol.appendChild(agHd);
  agentData.forEach(function(a) {
    var ac = document.createElement('div');
    ac.className = 'sol-ac fade-up';
    ac.innerHTML = '<div class="sol-acode">' + (AGENT_ICONS[a.code] || a.code) + '</div>'
      + '<div>'
        + '<div class="sol-apill">' + a.domain + '</div>'
        + '<div class="sol-aname">' + a.name + '</div>'
        + '<div class="sol-adesc">' + a.desc + '</div>'
      + '</div>'
      + '<div class="sol-astat">'
        + '<div class="sol-aval">' + a.stat + '</div>'
        + '<div class="sol-albl">' + a.lbl + '</div>'
      + '</div>';
    leftCol.appendChild(ac);
  });

  // COL 2: key capabilities
  var rightCol = document.createElement('div');
  rightCol.className = 'sol-rcol';
  var singlePanel = document.createElement('div');
  singlePanel.className = 'sol-panel fade-up';
  var capsHd = document.createElement('div');
  capsHd.className = 'sol-col-hd';
  capsHd.textContent = 'Key capabilities';
  singlePanel.appendChild(capsHd);
  var capsGrid = document.createElement('div');
  capsGrid.className = 'sol-caps-grid';
  s.caps.forEach(function(c) {
    var cap = document.createElement('div');
    cap.className = 'sol-cap';
    cap.innerHTML = '<div class="sol-ck"></div><div class="sol-ct">' + c + '</div>';
    capsGrid.appendChild(cap);
  });
  singlePanel.appendChild(capsGrid);

  // For IT Operations: embed scenarios inside the panel below caps
  if (id === 'it' && s.usecases && s.usecases.length) {
    var scDiv = document.createElement('div');
    scDiv.style.cssText = 'margin-top:16px;padding-top:14px;border-top:1px solid rgba(255,255,255,.07)';
    var scHd = document.createElement('div');
    scHd.className = 'sol-col-hd';
    scHd.textContent = 'Real-world scenarios';
    scDiv.appendChild(scHd);
    var scGrid = document.createElement('div');
    scGrid.className = 'sol-scgrid';
    s.usecases.forEach(function(uc) {
      var sc = document.createElement('div');
      sc.className = 'sol-sc';
      sc.innerHTML = '<div class="sol-sc-t">' + uc.title + '</div>'
        + '<div class="sol-sc-b">' + uc.body + '</div>';
      scGrid.appendChild(sc);
    });
    scDiv.appendChild(scGrid);
    singlePanel.appendChild(scDiv);
  }

  rightCol.appendChild(singlePanel);

  mgrid.appendChild(leftCol);
  mgrid.appendChild(rightCol);
  container.appendChild(mgrid);

  // ── SCENARIO ROW: 4-card strip below (security & compliance only) ──
  if (id !== 'it' && s.usecases && s.usecases.length) {
    var scRow = document.createElement('div');
    scRow.className = 'sol-sc-row';
    var scRowHd = document.createElement('div');
    scRowHd.className = 'sol-sc-row-hd';
    scRowHd.textContent = 'Real-world scenarios';
    scRow.appendChild(scRowHd);
    var sc4 = document.createElement('div');
    sc4.className = 'sol-sc-4grid';
    s.usecases.forEach(function(uc) {
      var card = document.createElement('div');
      card.className = 'sol-sc-card fade-up';
      card.innerHTML = '<div class="sol-sc-card-t">' + uc.title + '</div>'
        + '<div class="sol-sc-card-b">' + uc.body + '</div>';
      sc4.appendChild(card);
    });
    scRow.appendChild(sc4);
    container.appendChild(scRow);
  }

  // ── CTA STRIP ──
  var cta = document.createElement('div');
  cta.className = 'sol-cta fade-up';
  var ctaText = document.createElement('div');
  ctaText.innerHTML = '<div class="sol-cta-h">Ready to deploy ' + s.title + '?</div>'
    + '<div class="sol-cta-s">Live in 5 business days · No professional services required · First agent handling real requests by end of week one</div>';
  var ctaBtn = document.createElement('button');
  ctaBtn.className = 'sol-cta-btn';
  ctaBtn.textContent = 'Get started with ' + s.title + ' →';
  ctaBtn.onclick = function() { go('contact'); };
  cta.appendChild(ctaText);
  cta.appendChild(ctaBtn);
  container.appendChild(cta);

  lucide.createIcons();
}

/* ── BUILD: PRICING ───────────────────────────────────── */
function buildPricing() {
  var grid = document.getElementById('pricingGrid');
  if (!grid || grid.dataset.built) return;
  grid.dataset.built = '1';

  var plans = [
    {
      name: 'Essential',
      tier: 'Up to 100 users',
      amount: '$999',
      period: 'per month · annual billing',
      featured: false,
      btnClass: 'btn-outline',
      btnText: 'Start with Essential',
      features: ['3 active agents','Up to 100 users','10 connectors included','Employee self-service portal','Full audit trail — 7-day retention','Email + Teams notifications','ISO 27001 & SOC 2 aligned','Standard SLA (next business day)']
    },
    {
      name: 'Professional',
      tier: '100 – 500 users',
      amount: '$1,999',
      period: 'per month · annual billing',
      featured: false,
      btnClass: 'btn-ghost',
      btnText: 'Start with Professional',
      features: ['6 active agents','Up to 500 users','20 connectors','Admin Console + policy editor','Full audit trail — 30-day retention','SSO (SAML / OIDC)','4-hour SLA for P1 incidents','NESA, ISO 27001, SOC 2 aligned','GCC Cloud compliant']
    },
    {
      name: 'Enterprise',
      tier: '500 – 2,000 users',
      amount: '$3,999',
      period: 'per month · annual billing',
      featured: true,
      badge: 'Most popular',
      btnClass: 'btn-primary',
      btnText: 'Get Enterprise access',
      features: ['9 active agents','Up to 2,000 users','30 connectors','All portal screens + Admin Console','Full audit trail — 90-day retention','SSO (SAML / OIDC) + MFA enforced','4-hour P1 / 8-hour P2 SLA','Dedicated customer success manager','SOC 2 Type II evidence package','NESA, PDPL, ISO 27001, PCI DSS','GCC Cloud compliant · AWS region choice']
    },
    {
      name: 'Enterprise Plus',
      tier: '2,000+ users · Custom',
      amount: 'Custom',
      period: 'tailored deployment',
      featured: false,
      btnClass: 'btn-gold',
      btnText: 'Talk to our team',
      features: ['All 12 agents + all connectors','Unlimited users','Single-tenant or private cloud','On-premises deployment available','Full audit trail — 1-year retention','Bring your own VPC (BYOVPC)','Custom LLM configuration','Dedicated security & architecture review','Custom SLAs and escalation paths','Government & regulated industry ready','Ministry-level data classification']
    },
  ];

  grid.style.cssText = 'display:grid;grid-template-columns:repeat(4,1fr);gap:18px;align-items:start;margin-bottom:60px';

  plans.forEach(function(p) {
    var card = document.createElement('div');
    card.className = 'price-card' + (p.featured ? ' featured' : '') + ' fade-up';
    if (p.badge) {
      var badge = document.createElement('div');
      badge.className = 'price-badge'; badge.textContent = p.badge;
      card.appendChild(badge);
    }
    var list = p.features.map(function(f) { return '<li>' + f + '</li>'; }).join('');
    card.innerHTML += '<div style="font-size:10px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;color:var(--text-3);margin-bottom:6px">' + p.tier + '</div>'
      + '<div class="p-name">' + p.name + '</div>'
      + '<div class="p-amt" style="font-size:32px">' + p.amount + '</div>'
      + '<div class="p-period">' + p.period + '</div>'
      + '<hr style="border-color:rgba(255,255,255,.08);margin:16px 0"/>'
      + '<ul class="p-list">' + list + '</ul>';
    var btn = document.createElement('button');
    btn.className = 'btn ' + p.btnClass + ' btn-full';
    btn.textContent = p.btnText;
    btn.onclick = function() { go('contact'); };
    card.appendChild(btn);
    grid.appendChild(card);
  });

  // comparison table
  var tableWrap = document.getElementById('compareTable');
  if (!tableWrap) return;
  var rows = [
    ['Users','Up to 100','Up to 500','Up to 2,000','2,000+'],
    ['Active agents','3','6','9','12'],
    ['Connectors','10','20','30','70+'],
    ['Portal screens','Self-service','Admin + portal','All screens','All + custom'],
    ['Audit trail retention','7 days','30 days','90 days','1 year'],
    ['GCC Cloud compliant','—','✓','✓','✓'],
    ['SOC 2 Type II evidence','—','—','✓','✓'],
    ['SSO (SAML / OIDC)','—','✓','✓','✓'],
    ['MFA','Admins only','Admins only','All users','All users'],
    ['Data residency','Shared cloud','Shared cloud','AWS region choice','BYOVPC / On-prem'],
    ['Support SLA','Next business day','4h P1','4h P1 / 8h P2','Custom'],
    ['Customer success manager','—','—','Dedicated','Dedicated + SA'],
    ['Custom LLM','—','—','—','✓'],
    ['Private / sovereign cloud','—','—','—','✓'],
  ];
  var table = document.createElement('table');
  table.className = 'cmp-table fade-up';
  table.innerHTML = '<thead><tr>'
    + '<th>Feature</th>'
    + '<th>Essential</th>'
    + '<th>Professional</th>'
    + '<th class="th-ent">Enterprise</th>'
    + '<th class="th-sov">Enterprise Plus</th>'
    + '</tr></thead>';
  var tbody = document.createElement('tbody');
  rows.forEach(function(r) {
    var tr = document.createElement('tr');
    tr.innerHTML = '<td>' + r[0] + '</td>'
      + '<td style="text-align:center;color:var(--text-3)">' + r[1] + '</td>'
      + '<td style="text-align:center;color:var(--text-2)">' + r[2] + '</td>'
      + '<td style="text-align:center" class="td-ent">' + r[3] + '</td>'
      + '<td style="text-align:center" class="td-sov">' + r[4] + '</td>';
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  tableWrap.appendChild(table);
  tableWrap.style.overflowX = 'auto';
}

/* ── BUILD: CONTACT ───────────────────────────────────── */
function buildContact() {
  var stepsEl = document.getElementById('nextSteps');
  if (!stepsEl || stepsEl.dataset.built) return;
  stepsEl.dataset.built = '1';
  var steps = [
    ['Within 4 hours','Our team confirms your demo slot and sends a calendar invite.'],
    ['Demo call (45 min)','Live walkthrough of the platform tailored to your team and use cases.'],
    ['Technical review','Security questionnaire response, architecture brief, and data residency confirmation.'],
    ['Contract & onboarding','Sign → Day-1 provisioning → first agent live within 5 business days.'],
  ];
  steps.forEach(function(s, i) {
    var row = document.createElement('div');
    row.className = 'onboard-step fade-up';
    row.innerHTML = '<div class="step-dot">' + (i + 1) + '</div>'
      + '<div><div style="font-size:13.5px;font-weight:700;color:var(--text-1)">' + s[0] + '</div><div style="font-size:13px;color:var(--text-3);margin-top:3px">' + s[1] + '</div></div>';
    stepsEl.appendChild(row);
  });
}

/* ── FORM SUBMIT ──────────────────────────────────────── */
function submitForm(e) {
  e.preventDefault();
  document.getElementById('contactForm').style.display = 'none';
  document.getElementById('formSuccess').style.display = 'block';
}

/* ── GSAP ANIMATIONS CONTROLLER ─────────────────────────── */
var activePath = null;
var pageContent = null;
var dynamicSvg = null;
var bgPath = null;

function initFades() {
  gsap.set('.fade-up', { opacity: 0, y: 28 });
  document.querySelectorAll('.fade-up').forEach(el => {
    ScrollTrigger.create({
      trigger: el, start: 'top 88%', once: true,
      onEnter: () => gsap.to(el, { opacity: 1, y: 0, duration: 0.7, ease: 'power2.out', delay: parseFloat(el.style.animationDelay || 0) })
    });
  });
}

function initCounters() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    ScrollTrigger.create({ trigger: el, start: 'top 85%', once: true,
      onEnter: () => gsap.to({ v: 0 }, { v: target, duration: 2, ease: 'power2.out',
        onUpdate: function() { el.textContent = this.targets()[0].v.toFixed(target % 1 !== 0 ? 1 : 0) + suffix; }
      })
    });
  });
}

function initLogos() {
  gsap.set('.logo-item', { opacity: 0 });
  ScrollTrigger.create({ trigger: '#logos-strip', start: 'top 85%', once: true,
    onEnter: () => gsap.to('.logo-item', { opacity: 0.38, duration: 0.6, stagger: 0.1, ease: 'power2.out' })
  });
}

function initCards() {
  ['.card', '.agent-card', '.price-card', '.cmp-table'].forEach(sel => {
    gsap.set(sel, { opacity: 0, y: 26 });
    document.querySelectorAll(sel).forEach(card => {
      ScrollTrigger.create({ trigger: card, start: 'top 85%', once: true,
        onEnter: () => gsap.to(card, { opacity: 1, y: 0, duration: 0.65, ease: 'power2.out' })
      });
    });
  });
}

function initFloating() {
  document.querySelectorAll('.id-alert-card').forEach((c, i) => {
    gsap.to(c, { y: i % 2 === 0 ? -7 : 7, duration: 2.5 + i * 0.5, ease: 'sine.inOut', repeat: -1, yoyo: true, delay: i * 0.4 });
  });
}

function initHero() {
  gsap.from('.hero-left > *', { opacity: 0, y: 40, duration: 0.9, stagger: 0.15, ease: 'power3.out', delay: 0.3 });
  gsap.from('.dashboard-wrap', { opacity: 0, y: 50, scale: 0.96, duration: 1, ease: 'power3.out', delay: 0.6 });
}

function initDrift() {
  for (let i = 0; i < 14; i++) {
    const d = document.createElement('div');
    const s = Math.random() * 2.5 + 1;
    d.style.cssText = `position:fixed;border-radius:50%;pointer-events:none;z-index:1;width:${s}px;height:${s}px;left:${Math.random()*100}vw;top:${Math.random()*100}vh;background:rgba(20,184,166,${(Math.random()*.15+.04).toFixed(2)});animation:drft${i} ${12+Math.random()*18}s ease-in-out infinite;`;
    document.body.appendChild(d);
    const st = document.createElement('style');
    const dx = (Math.random()-.5)*180, dy = (Math.random()-.5)*180;
    st.textContent = `@keyframes drft${i}{0%,100%{transform:translate(0,0);opacity:.07}50%{transform:translate(${dx}px,${dy}px);opacity:.18}}`;
    document.head.appendChild(st);
  }
}

function initHeroTitleSlider() {
  const wrapper = document.getElementById("hero-title-slider");
  const slideItems = document.querySelectorAll(".slide-text");
  const totalSlides = slideItems.length;
  let currentIndex = 0;

  function getSlideHeight() {
    return slideItems.length > 0 ? slideItems[0].offsetHeight : 80;
  }

  function updateBrandingAccent(index) {
    const badge = document.getElementById("hero-badge");
    const ctaBtn = document.getElementById("hero-cta-btn");
    if (!badge || !ctaBtn) return;
    
    if (index === 3) { 
      badge.className = "badge badge-orchid";
      badge.innerHTML = "<span class='badge-dot' style='background:var(--gold-bright)'></span>GCC Cloud Compliant · Sovereign Cloud";
      ctaBtn.className = "btn btn-gold";
    } else { 
      badge.className = "badge";
      badge.innerHTML = "<span class='badge-dot'></span>Introducing One Concord AI";
      ctaBtn.className = "btn btn-primary";
    }
  }

  function goToNextSlide() {
    currentIndex++;
    if (currentIndex >= totalSlides) {
      currentIndex = 0;
    }
    const currentHeight = getSlideHeight();
    gsap.to(wrapper, {
      y: -(currentIndex * currentHeight),
      duration: 0.6,
      ease: "power3.inOut",
      onStart: () => updateBrandingAccent(currentIndex)
    });
  }

  setInterval(goToNextSlide, 3000);
  window.addEventListener("resize", () => {
    if (wrapper) gsap.set(wrapper, { y: -(currentIndex * getSlideHeight()) });
  });
}

function updatePathDimensions() {
  if (!pageContent || !activePath) return;
  const totalHeight = pageContent.offsetHeight;
  const totalWidth = window.innerWidth;
  const centerPoint = totalWidth / 2;

  dynamicSvg.setAttribute("width", totalWidth);
  dynamicSvg.setAttribute("height", totalHeight);
  dynamicSvg.setAttribute("viewBox", `0 0 ${totalWidth} ${totalHeight}`);

  // Curve starts from the top M center,0
  const pathData = `
    M ${centerPoint},0 
    C ${centerPoint},${totalHeight * 0.12} ${centerPoint + 300},${totalHeight * 0.14} ${centerPoint + 300},${totalHeight * 0.22} 
    S ${centerPoint - 300},${totalHeight * 0.26} ${centerPoint - 300},${totalHeight * 0.33} 
    S ${centerPoint + 300},${totalHeight * 0.37} ${centerPoint + 300},${totalHeight * 0.43} 
    S ${centerPoint - 300},${totalHeight * 0.47} ${centerPoint - 300},${totalHeight * 0.53} 
    S ${centerPoint + 300},${totalHeight * 0.58} ${centerPoint + 300},${totalHeight * 0.66} 
    S ${centerPoint - 200},${totalHeight * 0.74} ${centerPoint},${totalHeight * 0.84} 
    L ${centerPoint},${totalHeight - 120}
  `;

  bgPath.setAttribute("d", pathData);
  activePath.setAttribute("d", pathData);

  const pathLength = activePath.getTotalLength();
  gsap.set(activePath, {
    strokeDasharray: pathLength,
    strokeDashoffset: pathLength
  });
}

function initSvgLine() {
  pageContent = document.getElementById("page-content");
  dynamicSvg = document.getElementById("dynamic-svg");
  bgPath = document.getElementById("bg-path");
  activePath = document.getElementById("active-path");

  if (!pageContent || !activePath) return;

  updatePathDimensions();
  const layoutObserver = new ResizeObserver(() => updatePathDimensions());
  layoutObserver.observe(pageContent);
  window.addEventListener("resize", updatePathDimensions);

  ScrollTrigger.create({
    trigger: "#page-content",
    start: "top top",
    end: "bottom bottom",
    scrub: 1.2,
    onUpdate: (self) => {
      const pathLength = activePath.getTotalLength();
      gsap.set(activePath, {
        strokeDashoffset: pathLength * (1 - self.progress)
      });
    }
  });

  document.querySelectorAll("[data-line-card]").forEach((card) => {
    ScrollTrigger.create({
      trigger: card,
      start: "top 65%",
      end: "bottom 35%",
      onEnter: () => card.classList.add("line-active"),
      onLeave: () => card.classList.remove("line-active"),
      onEnterBack: () => card.classList.add("line-active"),
      onLeaveBack: () => card.classList.remove("line-active")
    });
  });
}

function initTimelineAnimation() {
  const progressLine = document.getElementById('timelineProgress');
  if (progressLine) {
    ScrollTrigger.create({
      trigger: '.timeline-container',
      start: 'top 70%',
      end: 'bottom 70%',
      scrub: true,
      onUpdate: (self) => {
        gsap.to(progressLine, { height: `${self.progress * 100}%`, duration: 0.1, overwrite: 'auto' });
      }
    });
  }

  document.querySelectorAll('.timeline-item').forEach(item => {
    const isLeft = item.classList.contains('timeline-left');
    const initialX = window.innerWidth <= 768 ? -28 : (isLeft ? -28 : 28);
    gsap.set(item, { opacity: 0, x: initialX });

    ScrollTrigger.create({
      trigger: item,
      start: 'top 80%',
      once: true,
      onEnter: () => {
        gsap.to(item, { opacity: 1, x: 0, duration: 0.8, ease: 'power2.out' });
      }
    });
  });
}


/* ── GRC PLATFORM CORE LOGIC ────────────────────────── */
var grcTimer = null;

function drawGrcLines() {
  const container = document.querySelector('.grc-platform-wrapper');
  if (!container) return;

  const rectContainer = container.getBoundingClientRect();

  function getDotCoords(dotEl) {
    if (!dotEl) return { x: 0, y: 0 };
    const rect = dotEl.getBoundingClientRect();
    return {
      x: rect.left - rectContainer.left + rect.width / 2,
      y: rect.top - rectContainer.top + rect.height / 2
    };
  }

  const centerLeftDot = document.querySelector('.grc-center-dot-left');
  const centerRightDot = document.querySelector('.grc-center-dot-right');
  if (!centerLeftDot || !centerRightDot) return;

  const cLeft = getDotCoords(centerLeftDot);
  const cRight = getDotCoords(centerRightDot);

  // Left to Center paths
  for (let i = 1; i <= 3; i++) {
    const cardDot = document.querySelector(`#grc-card-left-${i} .grc-card-dot-right`);
    const pathBg = document.getElementById(`grc-path-left-${i}`);
    const pathPulse = document.getElementById(`grc-pulse-left-${i}`);

    if (cardDot && pathBg && pathPulse) {
      const pt = getDotCoords(cardDot);
      const cp1x = pt.x + (cLeft.x - pt.x) * 0.5;
      const cp2x = pt.x + (cLeft.x - pt.x) * 0.5;
      const d = `M ${pt.x} ${pt.y} C ${cp1x} ${pt.y}, ${cp2x} ${cLeft.y}, ${cLeft.x} ${cLeft.y}`;
      pathBg.setAttribute('d', d);
      pathPulse.setAttribute('d', d);
    }
  }

  // Center to Right paths
  for (let i = 1; i <= 3; i++) {
    const cardDot = document.querySelector(`#grc-card-right-${i} .grc-card-dot-left`);
    const pathBg = document.getElementById(`grc-path-right-${i}`);
    const pathPulse = document.getElementById(`grc-pulse-right-${i}`);

    if (cardDot && pathBg && pathPulse) {
      const pt = getDotCoords(cardDot);
      const cp1x = cRight.x + (pt.x - cRight.x) * 0.5;
      const cp2x = cRight.x + (pt.x - cRight.x) * 0.5;
      const d = `M ${cRight.x} ${cRight.y} C ${cp1x} ${cRight.y}, ${cp2x} ${pt.y}, ${pt.x} ${pt.y}`;
      pathBg.setAttribute('d', d);
      pathPulse.setAttribute('d', d);
    }
  }
}

function initGrcCoreSection() {
  const cards = document.querySelectorAll('.grc-card');
  if (cards.length === 0) return;

  const flows = ['left-1', 'left-2', 'left-3', 'right-1', 'right-2', 'right-3'];
  let activeIndex = 0;

  function setActiveFlow(flowId) {
    cards.forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.grc-flow-pulse').forEach(p => p.classList.remove('active-pulse'));

    const activeCard = document.querySelector(`.grc-card[data-flow="${flowId}"]`);
    if (activeCard) {
      activeCard.classList.add('active');
    }

    const activePulse = document.getElementById(`grc-pulse-${flowId}`);
    if (activePulse) {
      activePulse.classList.add('active-pulse');
    }
  }

  // Click handler
  cards.forEach(card => {
    card.addEventListener('click', function() {
      const flowId = this.getAttribute('data-flow');
      activeIndex = flows.indexOf(flowId);
      setActiveFlow(flowId);
      resetGrcTimer();
    });
  });

  function startGrcTimer() {
    grcTimer = setInterval(() => {
      activeIndex = (activeIndex + 1) % flows.length;
      setActiveFlow(flows[activeIndex]);
    }, 3500);
  }

  function resetGrcTimer() {
    if (grcTimer) {
      clearInterval(grcTimer);
    }
    startGrcTimer();
  }

  // Init first flow
  setActiveFlow(flows[0]);
  startGrcTimer();

  // Draw lines
  setTimeout(drawGrcLines, 100);
  window.addEventListener('resize', drawGrcLines);

  const container = document.querySelector('.grc-platform-wrapper');
  if (container) {
    const observer = new ResizeObserver(() => drawGrcLines());
    observer.observe(container);
  }
}

/* ── VISIBILITY ISOMETRIC GRID LOGIC ─────────────────── */
function initVisibilityGrid() {
  const svg = document.getElementById('visibilityIsoSvg');
  if (!svg) return;

  svg.innerHTML = '';

  const rect = svg.getBoundingClientRect();
  const width = rect.width || window.innerWidth;
  const height = rect.height || 600;

  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);

  const S = 60; // side length of isometric cubes
  const dx = S * Math.sqrt(3); // spacing horizontally
  const dy = S * 1.5; // spacing vertically

  const cols = Math.ceil(width / dx) + 2;
  const rows = Math.ceil(height / dy) + 2;

  let gridGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  let pulseGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  svg.appendChild(gridGroup);
  svg.appendChild(pulseGroup);

  for (let r = -1; r < rows; r++) {
    for (let c = -1; c < cols; c++) {
      let x = c * dx;
      if (r % 2 === 0) {
        x += dx / 2;
      }
      let y = r * dy;

      // Draw cube lines from this center
      createLine(gridGroup, x, y, x, y + S);
      createLine(gridGroup, x, y, x - dx/2, y - S/2);
      createLine(gridGroup, x, y, x + dx/2, y - S/2);
      
      createLine(gridGroup, x - dx/2, y - S/2, x - dx/2, y + S/2);
      createLine(gridGroup, x - dx/2, y + S/2, x, y + S);
      createLine(gridGroup, x, y + S, x + dx/2, y + S/2);
      createLine(gridGroup, x + dx/2, y + S/2, x + dx/2, y - S/2);

      // Randomly create dynamic animated paths along grid paths
      if (Math.random() < 0.22) {
        createPulsePath(pulseGroup, x, y, S, dx);
      }

    }
  }
}
/* ── COMPLIANCE ISOMETRIC GRID LOGIC ─────────────────── */
function initComplianceGrid() {
  const svg = document.getElementById('complianceIsoSvg');
  if (!svg) return;

  svg.innerHTML = '';

  const rect = svg.getBoundingClientRect();
  const width = rect.width || window.innerWidth;
  const height = rect.height || 600;

  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);

  const S = 60; // side length of isometric cubes
  const dx = S * Math.sqrt(3); // spacing horizontally
  const dy = S * 1.5; // spacing vertically

  const cols = Math.ceil(width / dx) + 2;
  const rows = Math.ceil(height / dy) + 2;

  let gridGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  let pulseGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  svg.appendChild(gridGroup);
  svg.appendChild(pulseGroup);

  for (let r = -1; r < rows; r++) {
    for (let c = -1; c < cols; c++) {
      let x = c * dx;
      if (r % 2 === 0) {
        x += dx / 2;
      }
      let y = r * dy;

      // Draw cube lines from this center
      createLine(gridGroup, x, y, x, y + S);
      createLine(gridGroup, x, y, x - dx/2, y - S/2);
      createLine(gridGroup, x, y, x + dx/2, y - S/2);
      
      createLine(gridGroup, x - dx/2, y - S/2, x - dx/2, y + S/2);
      createLine(gridGroup, x - dx/2, y + S/2, x, y + S);
      createLine(gridGroup, x, y + S, x + dx/2, y + S/2);
      createLine(gridGroup, x + dx/2, y + S/2, x + dx/2, y - S/2);

      // Randomly create dynamic animated paths along grid paths
      if (Math.random() < 0.22) {
        createPulsePath(pulseGroup, x, y, S, dx);
      }
    }
  }

  function createLine(parent, x1, y1, x2, y2) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', x1);
    line.setAttribute('y1', y1);
    line.setAttribute('x2', x2);
    line.setAttribute('y2', y2);
    line.setAttribute('class', 'iso-grid-line');
    parent.appendChild(line);
  }

  function createPulsePath(parent, x, y, S, dx) {
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    let d = `M ${x} ${y}`;
    let cx = x;
    let cy = y;

    for (let step = 0; step < 4; step++) {
      const dir = Math.floor(Math.random() * 6);
      switch(dir) {
        case 0: cx += 0; cy += S; break;
        case 1: cx += 0; cy -= S; break;
        case 2: cx -= dx/2; cy -= S/2; break;
        case 3: cx -= dx/2; cy += S/2; break;
        case 4: cx += dx/2; cy -= S/2; break;
        case 5: cx += dx/2; cy += S/2; break;
      }
      d += ` L ${cx} ${cy}`;
    }

    path.setAttribute('d', d);
    path.setAttribute('class', 'iso-grid-pulse');
    path.setAttribute('stroke', Math.random() < 0.5 ? 'var(--accent-cyan)' : 'var(--accent)');
    path.setAttribute('stroke-width', '1.5');
    path.setAttribute('fill', 'none');
    
    path.style.animationDelay = `${Math.random() * 8}s`;
    path.style.animationDuration = `${6 + Math.random() * 6}s`;

    parent.appendChild(path);
  }
}


/* ── INITIALIZE ON LOAD ────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function() {
  gsap.registerPlugin(ScrollTrigger);

  // 1. Ingest common header & footer assets
  buildNav();
  buildTicker();

  // 2. Setup menu/scrolling event triggers (common)
  const header = document.getElementById('site-header');
  window.addEventListener('scroll', () => {
    if (header) header.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });

  document.querySelectorAll('.sol-tab').forEach(function(b) {
    b.addEventListener('click', function() { buildSolutions(this.dataset.sol, this); });
  });

  // 3. Detect current page filename
  const path = window.location.pathname.toLowerCase();
  const isHomepage = path.endsWith('index1.html') || path.endsWith('/') || path.endsWith('') || (!path.includes('.html'));

  if (path.endsWith('platform.html')) {
    buildPlatform();
  } else if (path.endsWith('agents.html')) {
    buildAgentGrid();
    buildAgentExtras();
  } else if (path.endsWith('solutions.html')) {
    buildSolutions('it');
  } else {
    // We are on index1.html (homepage)
    buildHome();
    buildPricing();
    buildContact();

    // Homepage-only visual components
    initHero();
    initDrift();
    initSvgLine();
    initHeroTitleSlider();
    initTimelineAnimation();
    initGrcCoreSection();
    initComplianceGrid();
  }

  // 4. Initialize common visual enhancements
  lucide.createIcons();
  initFades();
  initCounters();
  initLogos();
  initCards();
  initFloating();

  // 5. Read routing hash or default to home (homepage only)
  if (isHomepage) {
    var hash = window.location.hash.replace('#','');
    go(hash && document.getElementById('pg-' + hash) ? hash : 'home');
  }
});
